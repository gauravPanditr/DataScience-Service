# config.py

KAFKA_BOOTSTRAP_SERVERS = 'deciding-pheasant-13453-us1-kafka.upstash.io:9092'
KAFKA_TOPIC = 'expenseservice'
KAFKA_USERNAME = 'ZGVjaWRpbmctcGhlYXNhbnQtMTM0NTMkr8HKmEu2vwjqtLnp39zk5aTOUSwHOvk'
KAFKA_PASSWORD = 'ZmIxZjMyMWMtMjk1Zi00YWJlLTg1ZDItZGI4MjJjMTMzMTFi'
